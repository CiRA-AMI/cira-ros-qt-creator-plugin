#include <cira_bernoulli_opencv/cira_bernoulli_opencv.hpp>

int main() {
	cira_bernoulli_opencv* test = new cira_bernoulli_opencv();
	test->setTreeWidget();
	return 0;
}