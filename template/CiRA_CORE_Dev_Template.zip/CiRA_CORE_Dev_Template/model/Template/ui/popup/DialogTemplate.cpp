#include "DialogTemplate.h"
#include "ui_DialogTemplate.h"

DialogTemplate::DialogTemplate(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::DialogTemplate)
{
  ui->setupUi(this);
}

DialogTemplate::~DialogTemplate()
{
  delete ui;
}

QJsonObject DialogTemplate::saveState() {
  QJsonObject jso;

  return jso;
}

void DialogTemplate::restoreState(QJsonObject jso) {

}
